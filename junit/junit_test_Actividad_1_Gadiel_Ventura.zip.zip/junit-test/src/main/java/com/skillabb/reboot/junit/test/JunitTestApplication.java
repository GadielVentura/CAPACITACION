package com.skillabb.reboot.junit.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunitTestApplication {

  public static void main(String[] args) {
    SpringApplication.run(JunitTestApplication.class);
  }

}
